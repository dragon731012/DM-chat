# DM-chat
a static chat website that uses scaledrone so you can chat with your friends without a server!

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2Fdragon731012%2FDM-chat%2Ftree%2Fmain)
[![Deploy with Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/dragon731012/DM-chat)
